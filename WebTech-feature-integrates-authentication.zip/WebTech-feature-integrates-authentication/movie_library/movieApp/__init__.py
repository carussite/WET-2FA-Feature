default_app_config = 'movieApp.apps.MovieappConfig'
